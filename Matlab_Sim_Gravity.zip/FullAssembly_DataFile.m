% Simscape(TM) Multibody(TM) version: 24.2

% This is a model data file derived from a Simscape Multibody Import XML file using the smimport function.
% The data in this file sets the block parameter values in an imported Simscape Multibody model.
% For more information on this file, see the smimport function help page in the Simscape Multibody documentation.
% You can modify numerical values, but avoid any other changes to this file.
% Do not add code to this file. Do not edit the physical units shown in comments.

%%%VariableName:smiData


%============= RigidTransform =============%

%Initialize the RigidTransform structure array by filling in null values.
smiData.RigidTransform(18).translation = [0.0 0.0 0.0];
smiData.RigidTransform(18).angle = 0.0;
smiData.RigidTransform(18).axis = [0.0 0.0 0.0];
smiData.RigidTransform(18).ID = "";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(1).translation = [0 0 0.014];  % m
smiData.RigidTransform(1).angle = 0;  % rad
smiData.RigidTransform(1).axis = [0 0 0];
smiData.RigidTransform(1).ID = "B[21e0d1c75f5bb2ceb4ea1d58:MHfUknCADyeq9nSHC:-:21e0d1c75f5bb2ceb4ea1d58:Mx5Ddc684/gerRtZD]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(2).translation = [0 0 0.014];  % m
smiData.RigidTransform(2).angle = 0;  % rad
smiData.RigidTransform(2).axis = [0 0 0];
smiData.RigidTransform(2).ID = "F[21e0d1c75f5bb2ceb4ea1d58:MHfUknCADyeq9nSHC:-:21e0d1c75f5bb2ceb4ea1d58:Mx5Ddc684/gerRtZD]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(3).translation = [-0 0 0.010999999999999999];  % m
smiData.RigidTransform(3).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(3).axis = [1 0 0];
smiData.RigidTransform(3).ID = "B[3c4a2de4e646d6c16c77ed46:M/ArWtQV1sqjLC5kA:-:3c4a2de4e646d6c16c77ed46:Me/RhIiye7QNBkNEX]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(4).translation = [-0 0 0.010999999999999999];  % m
smiData.RigidTransform(4).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(4).axis = [1 0 0];
smiData.RigidTransform(4).ID = "F[3c4a2de4e646d6c16c77ed46:M/ArWtQV1sqjLC5kA:-:3c4a2de4e646d6c16c77ed46:Me/RhIiye7QNBkNEX]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(5).translation = [0 0 0];  % m
smiData.RigidTransform(5).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(5).axis = [-0.70710678118654746 0.70710678118654757 0];
smiData.RigidTransform(5).ID = "B[:-:MRJT7wlZiiWGz3txu:MHfUknCADyeq9nSHC]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(6).translation = [0 0 0.0178];  % m
smiData.RigidTransform(6).angle = 0;  % rad
smiData.RigidTransform(6).axis = [0 0 0];
smiData.RigidTransform(6).ID = "F[:-:MRJT7wlZiiWGz3txu:MHfUknCADyeq9nSHC]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(7).translation = [0 -0 0];  % m
smiData.RigidTransform(7).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(7).axis = [-0 0 1];
smiData.RigidTransform(7).ID = "B[MW7w/vua8/p2bCSSd:M/ArWtQV1sqjLC5kA:-:MM45x8a0swVA6ViW4]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(8).translation = [0 0 0];  % m
smiData.RigidTransform(8).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(8).axis = [-1 -0 -0];
smiData.RigidTransform(8).ID = "F[MW7w/vua8/p2bCSSd:M/ArWtQV1sqjLC5kA:-:MM45x8a0swVA6ViW4]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(9).translation = [0 0 0.01];  % m
smiData.RigidTransform(9).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(9).axis = [1 0 0];
smiData.RigidTransform(9).ID = "B[MiVEpAytcHXeHO8zX:-:MRJT7wlZiiWGz3txu:MHfUknCADyeq9nSHC]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(10).translation = [-0 -0.00046763399999999998 0.0178];  % m
smiData.RigidTransform(10).angle = 0;  % rad
smiData.RigidTransform(10).axis = [0 0 0];
smiData.RigidTransform(10).ID = "F[MiVEpAytcHXeHO8zX:-:MRJT7wlZiiWGz3txu:MHfUknCADyeq9nSHC]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(11).translation = [0 0 0];  % m
smiData.RigidTransform(11).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(11).axis = [-0 0 1];
smiData.RigidTransform(11).ID = "B[MRJT7wlZiiWGz3txu:Mx5Ddc684/gerRtZD:-:MnGSCT6X/E8yHTlXY]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(12).translation = [0 0 0];  % m
smiData.RigidTransform(12).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(12).axis = [1 0 0];
smiData.RigidTransform(12).ID = "F[MRJT7wlZiiWGz3txu:Mx5Ddc684/gerRtZD:-:MnGSCT6X/E8yHTlXY]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(13).translation = [0 0 0.0178];  % m
smiData.RigidTransform(13).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(13).axis = [1 0 0];
smiData.RigidTransform(13).ID = "B[MUyEEbKdQICABo85f:MHfUknCADyeq9nSHC:-:MnGSCT6X/E8yHTlXY]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(14).translation = [0 -0.014999999999999999 0.031];  % m
smiData.RigidTransform(14).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(14).axis = [-1 -0 -0];
smiData.RigidTransform(14).ID = "F[MUyEEbKdQICABo85f:MHfUknCADyeq9nSHC:-:MnGSCT6X/E8yHTlXY]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(15).translation = [0 0 0];  % m
smiData.RigidTransform(15).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(15).axis = [-0 -0 1];
smiData.RigidTransform(15).ID = "B[MUyEEbKdQICABo85f:Mx5Ddc684/gerRtZD:-:Mz1fJ+007AbNpGqiV]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(16).translation = [0 0 0];  % m
smiData.RigidTransform(16).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(16).axis = [-1 -0 -0];
smiData.RigidTransform(16).ID = "F[MUyEEbKdQICABo85f:Mx5Ddc684/gerRtZD:-:Mz1fJ+007AbNpGqiV]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(17).translation = [-0 0 0.20000000000000001];  % m
smiData.RigidTransform(17).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(17).axis = [1 0 0];
smiData.RigidTransform(17).ID = "B[Mz1fJ+007AbNpGqiV:-:MW7w/vua8/p2bCSSd:Me/RhIiye7QNBkNEX]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(18).translation = [0 0 0.014999999999999999];  % m
smiData.RigidTransform(18).angle = 0;  % rad
smiData.RigidTransform(18).axis = [0 0 0];
smiData.RigidTransform(18).ID = "F[Mz1fJ+007AbNpGqiV:-:MW7w/vua8/p2bCSSd:Me/RhIiye7QNBkNEX]";


%============= Solid =============%
%Center of Mass (CoM) %Moments of Inertia (MoI) %Product of Inertia (PoI)

%Initialize the Solid structure array by filling in null values.
smiData.Solid(8).mass = 0.0;
smiData.Solid(8).CoM = [0.0 0.0 0.0];
smiData.Solid(8).MoI = [0.0 0.0 0.0];
smiData.Solid(8).PoI = [0.0 0.0 0.0];
smiData.Solid(8).color = [0.0 0.0 0.0];
smiData.Solid(8).opacity = 0.0;
smiData.Solid(8).ID = "";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(1).mass = 60.481746799999996;  % g
smiData.Solid(1).CoM = [-7.9299999999999997e-07 0.0052031539999999998 0.071235337999999995];  % m
smiData.Solid(1).MoI = [0.19656400000000002 0.196293 0.0070829999999999999];  % g*m^2
smiData.Solid(1).PoI = [-0.022182 6.0000000000000002e-06 0];  % g*m^2
smiData.Solid(1).color = [0.615686275 0.811764706 0.929411765];
smiData.Solid(1).opacity = 1.000000000;
smiData.Solid(1).ID = "JHD*:*7c0b508be7796974fcf3f21b";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(2).mass = 8.0663318900000007;  % g
smiData.Solid(2).CoM = [-0 -0.00046663199999999997 0.015896606000000001];  % m
smiData.Solid(2).MoI = [0.00093700000000000001 0.001003 0.0019199999999999998];  % g*m^2
smiData.Solid(2).PoI = [0 0 0];  % g*m^2
smiData.Solid(2).color = [0.647058824 0.647058824 0.647058824];
smiData.Solid(2).opacity = 1.000000000;
smiData.Solid(2).ID = "JKD*:*a4790b6086507d3c8bfc72c3";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(3).mass = 38.331113600000002;  % g
smiData.Solid(3).CoM = [-0 0 0.00738851];  % m
smiData.Solid(3).MoI = [0.0046150000000000002 0.0046150000000000002 0.0077849999999999994];  % g*m^2
smiData.Solid(3).PoI = [0 0 0];  % g*m^2
smiData.Solid(3).color = [0.615686275 0.811764706 0.929411765];
smiData.Solid(3).opacity = 1.000000000;
smiData.Solid(3).ID = "JHD*:*a4790b6086507d3c8bfc72c3";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(4).mass = 21.602872900000001;  % g
smiData.Solid(4).CoM = [-0 0 0.0055351159999999996];  % m
smiData.Solid(4).MoI = [0.0018909999999999999 0.0018909999999999999 0.0033479999999999998];  % g*m^2
smiData.Solid(4).PoI = [0 0 0];  % g*m^2
smiData.Solid(4).color = [0.615686275 0.811764706 0.929411765];
smiData.Solid(4).opacity = 1.000000000;
smiData.Solid(4).ID = "JHD*:*5798b0cb2b4bd931bd56bf1c";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(5).mass = 8.8394937500000008;  % g
smiData.Solid(5).CoM = [-0 0 0.013504126];  % m
smiData.Solid(5).MoI = [0.00064800000000000003 0.00064800000000000003 0.001237];  % g*m^2
smiData.Solid(5).PoI = [0 0 0];  % g*m^2
smiData.Solid(5).color = [0.647058824 0.647058824 0.647058824];
smiData.Solid(5).opacity = 1.000000000;
smiData.Solid(5).ID = "JID*:*5798b0cb2b4bd931bd56bf1c";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(6).mass = 72.310479700000002;  % g
smiData.Solid(6).CoM = [-0.0093318970000000005 -0.007527382 0.0050207480000000002];  % m
smiData.Solid(6).MoI = [0.060219000000000002 0.061015 0.12002400000000001];  % g*m^2
smiData.Solid(6).PoI = [0.00019799999999999999 5.9999999999999995e-05 0.0059839999999999997];  % g*m^2
smiData.Solid(6).color = [0.615686275 0.811764706 0.929411765];
smiData.Solid(6).opacity = 1.000000000;
smiData.Solid(6).ID = "JHD*:*e70c3ddbc695d4288bc97441";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(7).mass = 30.737752;  % g
smiData.Solid(7).CoM = [9.6239999999999997e-06 -0.011468119000000001 0.018231827999999999];  % m
smiData.Solid(7).MoI = [0.011342999999999999 0.014276 0.0090980000000000002];  % g*m^2
smiData.Solid(7).PoI = [0.0027360000000000002 2.0000000000000003e-06 -1.0000000000000002e-06];  % g*m^2
smiData.Solid(7).color = [0.615686275 0.811764706 0.929411765];
smiData.Solid(7).opacity = 1.000000000;
smiData.Solid(7).ID = "JHD*:*bc7635f1117e7652cae453a4";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(8).mass = 103.03840699999999;  % g
smiData.Solid(8).CoM = [0 -0.00499681 0.092060669999999997];  % m
smiData.Solid(8).MoI = [0.42483599999999999 0.43607800000000002 0.012958000000000001];  % g*m^2
smiData.Solid(8).PoI = [-3.4e-05 0 0];  % g*m^2
smiData.Solid(8).color = [0.615686275 0.811764706 0.929411765];
smiData.Solid(8).opacity = 1.000000000;
smiData.Solid(8).ID = "JHD*:*232b2b52920ce7cf37ce2fec";


%============= Joint =============%
%X Revolute Primitive (Rx) %Y Revolute Primitive (Ry) %Z Revolute Primitive (Rz)
%X Prismatic Primitive (Px) %Y Prismatic Primitive (Py) %Z Prismatic Primitive (Pz) %Spherical Primitive (S)
%Constant Velocity Primitive (CV) %Lead Screw Primitive (LS)
%Position Target (Pos)

%Initialize the RevoluteJoint structure array by filling in null values.
smiData.RevoluteJoint(3).Rz.Pos = 0.0;
smiData.RevoluteJoint(3).ID = "";

smiData.RevoluteJoint(1).Rz.Pos = -90;  % deg
smiData.RevoluteJoint(1).ID = "[MRJT7wlZiiWGz3txu:MHfUknCADyeq9nSHC:-:MRJT7wlZiiWGz3txu:Mx5Ddc684/gerRtZD]";

smiData.RevoluteJoint(2).Rz.Pos = 179.28378410382365;  % deg
smiData.RevoluteJoint(2).ID = "[MUyEEbKdQICABo85f:MHfUknCADyeq9nSHC:-:MUyEEbKdQICABo85f:Mx5Ddc684/gerRtZD]";

smiData.RevoluteJoint(3).Rz.Pos = 0;  % deg
smiData.RevoluteJoint(3).ID = "[MW7w/vua8/p2bCSSd:M/ArWtQV1sqjLC5kA:-:MW7w/vua8/p2bCSSd:Me/RhIiye7QNBkNEX]";

